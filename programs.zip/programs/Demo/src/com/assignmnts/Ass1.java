package com.assignmnts;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ass1
 */
@WebServlet("/Ass1")
		//urlPatterns = {  }, 
		//initParams = {  
			//	@WebInitParam(name = "username", value = "Ramya"), 
				//@WebInitParam(name = "pasword", value = "foodislove")
	//	})
public class Ass1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ass1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	//public void init(ServletConfig config) throws ServletException {
		
	//}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("TEXT/HTML");
		PrintWriter out=response.getWriter();
		//ServletConfig config=getServletConfig();
		//String s=config.getInitParameter("a");
		//String s1=config.getInitParameter("b");
		String UserName=request.getParameter("username");
		//out.println("username:  "+UserName+"<br>");
		String password=request.getParameter("password");				
		//out.println("password:  "+password+"<br>");
		if(UserName.equals("Ramya")&&password.equals("foodislove"))
		{
			out.println("success");
		}
		else
		{
			out.println("login failed");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("TEXT/HTML");
		PrintWriter out=response.getWriter();
		String UserName=request.getParameter("username");
		//out.println("username:  "+UserName+"<br>");
		String password=request.getParameter("password");				
		//out.println("password:  "+password+"<br>");
		if((UserName.equals("Ramya"))&&(password.equals("foodislove")))
		{
			out.println("success");
		}
		else
		{
            out.println("login failed");
		}
	}

}
