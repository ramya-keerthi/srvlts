package com.ramya;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlt
 */
@WebServlet("/Servlt")
public class Servlt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("TEXT/HTML");
		PrintWriter out=response.getWriter();
		String UserName=request.getParameter("username");
		out.println("username:  "+UserName+"<br>");
		String password=request.getParameter("password");
		out.println("password:  "+password+"<br>");
		String qualification=request.getParameter("qualification");
		out.println("education qualification:       "+qualification+"<br>");
		String[] proofs=request.getParameterValues("proofs");
		System.out.println("values checked for proofs submitted are:");
		if(proofs!=null)
			{
			for(String proof : proofs){
				out.println("proofs submitted:    "+proof +"<br>");
			}
		}
		String[] hobbies=request.getParameterValues("hobbies");
		out.println("the entered hobbies are:   ");
		if(hobbies!=null)
			{
			for(String hobbie : hobbies){
				out.println(hobbie +"<br>");
			}
		}
		String city=request.getParameter("citylist");
		out.println("citylist:  "+city+"<br>");
		
		String queryString=request.getQueryString();
		out.println("query string:::"+queryString+"<br>");
		//out.println("userName:\n"+UserName+"password:\n"+password);
		String requestURI=request.getRequestURI();
		out.println("requesturi:::"+requestURI+"<br>");
		Enumeration<String> inputParameters=request.getParameterNames();
		while (inputParameters.hasMoreElements())
		{
					String param=inputParameters.nextElement();
					out.println(param);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("TEXT/HTML");
		PrintWriter out=response.getWriter();
		String UserName=request.getParameter("username");
		out.println("username:  "+UserName+"<br>");
		String password=request.getParameter("password");
		out.println("password:  "+password+"<br>");
		String qualification=request.getParameter("qualification");
		out.println("education qualification:       "+qualification+"<br>");
		String[] proofs=request.getParameterValues("proofs");
		System.out.println("values checked for proofs submitted are:");
		if(proofs!=null)
			{
			for(String proof : proofs){
				out.println("proofs submitted:    "+proof +"<br>");
			}
		}
		String[] hobbies=request.getParameterValues("hobbies");
		out.println("the entered hobbies are:   ");
		if(hobbies!=null)
			{
			for(String hobbie : hobbies){
				out.println(hobbie +"<br>");
			}
		}
		String city=request.getParameter("citylist");
		out.println("citylist:  "+city+"<br>");
		
		String queryString=request.getQueryString();
		out.println("query string:::"+queryString+"<br>");
		//out.println("userName:\n"+UserName+"password:\n"+password);
		String requestURI=request.getRequestURI();
		out.println("requesturi:::"+requestURI+"<br>");
		Enumeration<String> inputParameters=request.getParameterNames();
		while (inputParameters.hasMoreElements())
		{
					String param=inputParameters.nextElement();
					out.println(param);
		}
	}

}
