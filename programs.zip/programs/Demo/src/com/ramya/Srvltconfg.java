package com.ramya;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.jstl.core.Config;

/**
 * Servlet implementation class Srvltconfg
 */
@WebServlet(
		urlPatterns = { "/Srvltconfg" }, 
		initParams = { 
				@WebInitParam(name = "a", value = "2", description = "integr"), 
				@WebInitParam(name = "b", value = "3.5", description = "flt")
		})
public class Srvltconfg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Srvltconfg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("TEXT/HTML");
		PrintWriter out=response.getWriter();
		ServletConfig config=getServletConfig();
		String s=config.getInitParameter("a");
		String s1=config.getInitParameter("b");
		ServletContext ctx=request.getServletContext();
		//ctx.setAttribute("lastname","keerthi" );
		//ctx.setAttribute("name", "ramya");
		String b=(String) ctx.getAttribute("lastname");
		String b1=(String) ctx.getAttribute("name");
		out.println(s+"</br>"+s1);
		out.println(b+"</br>"+b1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
