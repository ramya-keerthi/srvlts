package com.ramya;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jdk.nashorn.internal.runtime.Context;

/**
 * Servlet implementation class Srvltcontxt
 */
@WebServlet("/Srvltcontxt")
public class Srvltcontxt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Srvltcontxt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("TEXT/HTML");
		PrintWriter out=response.getWriter();
		ServletContext ctx=request.getServletContext();
		ctx.setAttribute("lastname","keerthi" );
		ctx.setAttribute("name", "ramya");
		String b=(String) ctx.getAttribute("lastname");
		String b1=(String) ctx.getAttribute("name");
		out.println(b+"</br>"+b1);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
